<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="msapplication-TileColor" content="#2d89ef">
    <meta name="theme-color" content="#4188c9">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent"/>
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="HandheldFriendly" content="True">
    <meta name="MobileOptimized" content="320">

    <title>Pondokan Tjiburial | <?php echo $__env->yieldPushContent('title'); ?> </title>
    <link rel="icon" href="<?php echo e(asset('assets')); ?>/images/logo.png">

    
    <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/plugins/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/plugins/simple-line-icons/simple-line-icons.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/plugins/select2/select2.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/plugins/select2/select2-bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,300i,400,400i,500,500i,600,600i,700,700i&amp;subset=latin-ext">

    <link href="<?php echo e(asset('assets')); ?>/plugins/bootstrap-material-design/bootstrap-md.min.css" rel="stylesheet" />
    <link href="<?php echo e(asset('backend')); ?>/assets/css/dashboard.css" rel="stylesheet" />
    <link href="<?php echo e(asset('backend')); ?>/assets/css/custom.css" rel="stylesheet" />

    <?php echo $__env->yieldPushContent('css'); ?>
    <?php echo $__env->yieldPushContent('style'); ?>
</head>
<body>
<div class="page">
    <div class="page-main">
        
        <div class="header py-4">
            <div class="container">
                <div class="d-flex">
                    <img src="<?php echo e(asset('assets')); ?>/images/logo.png" class="logo" alt="Logo Choral Society" width="30" height="30">
                    <a class="header-brand" href="#">
                        <?php echo $__env->yieldContent('heading', 'Pondokan Tjiburial'); ?>
                    </a>
                    <div class="d-flex order-lg-2 ml-auto">
                        <div class="dropdown">
                            <a href="#" class="nav-link pr-0 leading-none" data-toggle="dropdown">
                                
                                    
                                
                                    
                                
                                    <span class="avatar" style="background-image: url('<?php echo e(asset('assets/images/user/male.png')); ?>')"></span>
                                
                                <span class="ml-2 d-none d-lg-block">
                                  <span class="text-default"><?php echo e(@\Auth::user()->name); ?></span>
                                  
                                      
                                          
                                      
                                          
                                      
                                  
                                </span>
                            </a>
                            <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                <a class="dropdown-item" href="#">
                                    <i class="dropdown-icon fe fe-user"></i> Profile
                                </a>
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                <a class="dropdown-item btnLogout" href="#">
                                    <i class="dropdown-icon fe fe-log-out"></i> Sign out
                                </a>
                                <form class="hidden" id="formLogout" action="<?php echo e(url('logout')); ?>" method="post">
                                    <?php echo csrf_field(); ?>

                                </form>
                            </div>
                        </div>
                    </div>
                    <a href="#" class="header-toggler d-lg-none ml-3 ml-lg-0" data-toggle="collapse" data-target="#headerMenuCollapse">
                        <span class="header-toggler-icon"></span>
                    </a>
                </div>
            </div>
        </div>
        <?php if(Request::is('event/register/*')): ?>
            <?php echo $__env->make('backend.templates.headerRegister', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php else: ?>
            <?php echo $__env->make('backend.templates.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php endif; ?>
        

        
        <div class="my-3 my-md-5">
            <?php echo $__env->yieldContent('content'); ?>
        </div>

    </div>
    <footer class="footer">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-12 col-lg-auto mt-3 mt-lg-0 text-center">
                    Copyright © <?php echo e(date('Y')); ?> <a href=".">Pondokan Tjiburial</a>. All rights reserved.
                </div>
            </div>
        </div>
    </footer>
</div>


<script src="<?php echo e(asset('assets')); ?>/plugins/jquery/jquery-3.1.0.min.js"></script>
<script src="<?php echo e(asset('backend')); ?>/assets/js/vendors/bootstrap.bundle.min.js"></script>
<script src="<?php echo e(asset('assets')); ?>/plugins/bootstrap-material-design/popper.js"></script>
<script src="<?php echo e(asset('assets')); ?>/plugins/bootstrap-material-design/bootstrap-md.js"></script>

<script src="<?php echo e(asset('backend')); ?>/assets/js/core.js"></script>
<script src="<?php echo e(asset('assets')); ?>/plugins/select2/select2.full.min.js"></script>
<script src="<?php echo e(asset('assets')); ?>/plugins/sweetalert/sweetalert.min.js"></script>

<?php echo $__env->yieldPushContent('js'); ?>
<?php echo $__env->yieldPushContent('script'); ?>
<script>
    $(document).ready(function(){
        $('body').bootstrapMaterialDesign();

        $('.btnLogout').on('click', function(e){
            e.preventDefault();

            $('#formLogout').submit();
        })
    });
</script>
</body>
</html>
