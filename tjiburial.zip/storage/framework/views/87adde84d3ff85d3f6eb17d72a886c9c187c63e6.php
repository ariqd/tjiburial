<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Pondokan Tjiburial | <?php echo $__env->yieldPushContent('title'); ?></title>
    <link rel="icon" href="<?php echo e(asset('assets')); ?>/images/logo.png">

    
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css"
          integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/css/custom.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" />

    <?php echo $__env->yieldPushContent('css'); ?>
    <?php echo $__env->yieldPushContent('style'); ?>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark" style="z-index:1000">
    <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
        <img src="<?php echo e(asset('assets')); ?>/images/logo.png" alt="Logo Tjiburial" width="50">
    </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mx-auto">
            <li class="nav-item <?php echo e(@request()->segments(2)[0] == '' ? 'active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(url('/')); ?>">HOME <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item <?php echo e(@request()->segments(2)[0] == 'features' ? 'active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(url('/features')); ?>">FEATURES</a>
            </li>
            <li class="nav-item <?php echo e(@request()->segments(2)[0] == 'blog' ? 'active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(url('/blog')); ?>">BLOG</a>
            </li>
            <li class="nav-item <?php echo e(@request()->segments(2)[0] == 'book' ? 'active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(url('/book')); ?>">BOOK</a>
            </li>
            <li class="nav-item <?php echo e(@request()->segments(2)[0] == 'about' ? 'active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(url('/about')); ?>">ABOUT</a>
            </li>
            <li class="nav-item <?php echo e(@request()->segments(2)[0] == 'faq' ? 'active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(url('/faq')); ?>">FAQ</a>
            </li>
            <li class="nav-item <?php echo e(@request()->segments(2)[0] == 'contact' ? 'active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(url('/contact')); ?>">CONTACT US</a>
            </li>
            <?php if(auth()->guard()->guest()): ?>
            <li class="nav-item <?php echo e(@request()->segments(2)[0] == 'login' ? 'active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(url('/login')); ?>">LOGIN</a>
            </li>
            <li class="nav-item <?php echo e(@request()->segments(2)[0] == 'register' ? 'active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(url('/register')); ?>">REGISTER</a>
            </li>
             <?php endif; ?>
            <?php if(auth()->guard()->check()): ?>
            <li class="nav-item <?php echo e(@request()->segments(2)[0] == 'profile' ? 'active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(url('/profile')); ?>">MY PROFILE</a>
            </li>
            <li class="nav-item">
                <a href="<?php echo e(route('logout')); ?>" class="nav-link btn btn-outline-secondary" onclick="event.preventDefault(); document.getElementById('frm-logout').submit();">
                    <i class="fa fa-sign-out"></i> LOGOUT
                </a>
                <form id="frm-logout" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                    <?php echo csrf_field(); ?>
                </form>
            </li>
            <?php endif; ?>
        </ul>
    </div>
</nav>


<?php echo $__env->yieldContent('content'); ?>


<script
        src="https://code.jquery.com/jquery-3.3.1.min.js"
        integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
        crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js" integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous"></script>
<?php echo $__env->yieldPushContent('js'); ?>
<?php echo $__env->yieldPushContent('script'); ?>

</body>
</html>
