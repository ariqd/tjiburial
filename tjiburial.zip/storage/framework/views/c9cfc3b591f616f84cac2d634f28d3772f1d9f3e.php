<?php $__env->startPush('title'); ?>
    Promotions
<?php $__env->stopPush(); ?>

<?php $__env->startPush('style'); ?>
    <style>
        .navbar {
            position: absolute;
            width: 100%;
        }
        .base {
            position: relative;
            top: 0;
            left: 0;
        }
        p {
            text-align: justify;
        }
        .img-fluid {
            display: inline-block;
        }

        .card {
            -webkit-border-radius: 0;
            -moz-border-radius: 0;
            border-radius: 0;
            border: 0;
        }

        input, textarea {
            border: 0;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="base">
        <img class="img-fluid" src="<?php echo e(asset('assets')); ?>/images/contact.png">
    </div>

    <?php echo $__env->make('frontend.templates.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.templates.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>