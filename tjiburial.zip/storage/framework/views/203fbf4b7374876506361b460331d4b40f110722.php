<?php $__env->startPush('title'); ?>
    Admin Page
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <h1 class="text-center">Pondokan Tjiburial Admin Panel</h1>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.templates.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>