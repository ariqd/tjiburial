@extends('backend.templates.main')

@push('title')
    Admin Page
@endpush

@section('content')
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <h1 class="text-center">Pondokan Tjiburial Admin Panel</h1>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection