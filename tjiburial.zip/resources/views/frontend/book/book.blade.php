@extends('frontend.templates.main')

@push('title')
    Book
@endpush

@push('style')
    <style>
        .navbar {
            position: absolute;
            width: 100%;
        }
        .base {
            width: 100%;
            height: 300px;
            position: relative;
            margin-left: auto;
            margin-right: auto;
            overflow: hidden;
            /*z-index: 0;*/
        }
        .base img {
            width: 100%;
            position: absolute;
            margin: auto;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            /*z-index: 0;*/
        }
        .img-fluid {
            display: inline-block;
        }

        .card {
            -webkit-border-radius: 0;
            -moz-border-radius: 0;
            border-radius: 0;
            border: 0;
        }

        input, textarea {
            border: 0;
        }

        .review, .price {
            line-height: 10px;
        }

        /*HOTEL FORM*/
        .hotel-form {
            border: 1px solid #9E9E9E;
            padding: 10px;
            border-radius: 7px;
        }
        .hotel-form .form-control, .form-control:focus {
            border: 0;
            outline: 0;
            -webkit-box-shadow: none;
            box-shadow: none;
        }

        .room {
            -webkit-border-radius: 2px;
            -moz-border-radius: 2px;
            border-radius: 2px;
            border: 1px solid #BDBDBD;
        }

        .expand:hover {
            cursor: pointer;
        }
        .detail {
            display: none;
        }
        /*.room .room-features {*/
            /*line-height: 10px;*/
        /*}*/
    </style>
@endpush

@push('script')
    <script>
        $(document).ready(function(){
            $(".expand").on( "click", function() {
                $(this).next().slideToggle(200);
            });
            $("#roomIdBtn").click(function() {
                $('html, body').animate({
                    scrollTop: $("#roomIdDiv").offset().top
                }, 1000);
            });
        });
    </script>
@endpush

@section('content')
    <div class="base">
        <img class="img-fluid" src="{{ asset('assets') }}/images/hotel.png">
    </div>

    <div class="container my-4">
        <div class="row">
            <div class="col-lg-12">
                <h4 class="text-center">Bookings</h4>
                <p class="text-center">Discover the rooms Hotel Pondokan Tjiburial offers</p>
            </div>
        </div>
        <div class="row mt-4">
            <div class="col-lg-8">
                <img class="img-fluid w-100" src="{{ asset('uploads') }}/hotel/hotel1.png">

            </div>
            <div class="col-lg-4">
                <h3 class="text-primary align-left">8.7 <small> / 10</small></h3>
                <p class="text-secondary">Based on 34 online reviews</p>
                <div class="review pt-3">
                    <p class="review-text">"Great View, Amazing Experience"</p>
                    <p class="review-people text-secondary">- Kevin T Gunawan, Google</p>
                </div>
                <div class="review pt-3">
                    <p class="review-text">"Great View, Amazing Experience"</p>
                    <p class="review-people text-secondary">- Kevin T Gunawan, Google</p>
                </div>
                <div class="price pt-5">
                    <p class="text-secondary">Starting from</p>
                    <h2>Rp 1.400.000</h2>
                </div>
                <button id="roomIdBtn" class="btn btn-tjiburial">Choose Room</button>
            </div>
        </div>
        <div class="row mt-5">
            <div class="col-lg-12">
                <form action="#">
                    <div class="row hotel-form">
                        <div class="col-lg-3">
                            <div class="form-row d-flex justify-content-between align-items-center border-right p-2">
                                <div class="col-10">
                                    <label for="checkin" class="hotel-form-label mb-1"><b>Check In</b></label>
                                    <input type="date" class="form-control" name="checkin" id="checkin">
                                </div>
                                <div class="col-2">
                                    <span class="fa fa-calendar fa-2x"></span>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div class="form-row d-flex justify-content-between align-items-center border-right p-2">
                                <div class="col-10">
                                    <label for="duration" class="hotel-form-label mb-1"><b>Duration</b></label>
                                    <select name="duration" id="duration" class="form-control custom-select">
                                        <option value="1">1 Night</option>
                                        <option value="2">2 Nights</option>
                                        <option value="3">3 Nights</option>
                                        <option value="4">4 Nights</option>
                                        <option value="5">5 Nights</option>
                                        <option value="6">6 Nights</option>
                                        <option value="7">7 Nights</option>
                                        <option value="8">8 Nights</option>
                                    </select>
                                </div>
                                <div class="col-2">
                                    <img src="{{ asset('assets') }}/images/duration.png" alt="duration">
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div class="form-row d-flex justify-content-between align-items-center border-right p-2">
                                <div class="col-10">
                                    <label for="guest" class="hotel-form-label mb-1"><b>Guests</b></label>
                                    <select name="guest" id="guest" class="form-control custom-select">
                                        <option value="1">1 Guest</option>
                                        <option value="2">2 Guests</option>
                                        <option value="3">3 Guests</option>
                                        <option value="4">4 Guests</option>
                                        <option value="5">5 Guests</option>
                                        <option value="6">6 Guests</option>
                                        <option value="7">7 Guests</option>
                                        <option value="8">8 Guests</option>
                                    </select>
                                    {{--<input type="date" class="form-control  name="checkout" id="checkout">--}}
                                </div>
                                <div class="col-2">
                                    <span class="fa fa-male fa-2x"></span>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div class="form-row d-flex justify-content-between align-items-center p-2">
                                <div class="col-10">
                                    <label for="rooms" class="hotel-form-label mb-1"><b>Rooms</b></label>
                                    <select name="rooms" id="rooms" class="form-control custom-select">
                                        <option value="1">1 Room</option>
                                        <option value="2">2 Rooms</option>
                                        <option value="3">3 Rooms</option>
                                        <option value="4">4 Rooms</option>
                                        <option value="5">5 Rooms</option>
                                        <option value="6">6 Rooms</option>
                                        <option value="7">7 Rooms</option>
                                        <option value="8">8 Rooms</option>
                                    </select>
                                </div>
                                <div class="col-2">
                                    <img src="{{ asset('assets') }}/images/rooms.png" alt="rooms">
                                </div>
                            </div>
                        </div>

                    </div>
                    {{--<div class="row my-5">--}}
                        {{--<div class="col-lg-12">--}}
                            {{--<div class="text-center">--}}
                                {{--<button type="submit" class="btn btn-tjiburial p-4">REQUEST A QUOTE</button>--}}
                            {{--</div>--}}
                        {{--</div>--}}
                    {{--</div>--}}
                </form>
            </div>
        </div>
        <div class="row mt-3">
            <div class="col-lg-12">
                <div class="card room" id="roomIdDiv">
                    <div class="card-body">

                        <div class="expand">
                            <div class="row">
                                <div class="col-lg-3">
                                    <img class="img-fluid w-100" src="{{ asset('uploads') }}/hotel/hotel1.png">
                                </div>
                                <div class="col-lg-6">
                                    <h3>Type of Room</h3>
                                    <p class="text-secondary">Max guests # person</p>
                                    <ul class="simple text-secondary">
                                        <li>Special features</li>
                                        <li>Special features</li>
                                        <li>Special features</li>
                                    </ul>
                                </div>
                                <div class="col-lg-3 text-right">
                                    <h4>Rp 1.400.000 <small> / night</small></h4>
                                    <p class="text-primary">Inclusive of taxes</p>
                                    <p>Installment is available for credit cardholders</p>
                                    <a href="#" class="btn btn-tjiburial text-light">Book Now</a>
                                </div>
                            </div>
                        </div>

                        <div class="detail">
                            <div class="row">
                                <div class="col-lg-6">
                                    {{--<h1>Hello</h1>--}}
                                    <img class="img-fluid w-100" src="{{ asset('uploads') }}/hotel/hotel1.png">
                                </div>
                                <div class="col-lg-6">
                                    <h4 class="text-bold">Room Overview</h4>
                                    <ul class="simple">
                                        <li>Bed type : 2 Regular beds</li>
                                    </ul>
                                    <h4 class="text-bold">Basic Facilities</h4>
                                    <ul class="simple">
                                        <li>Breakfast included</li>
                                    </ul>
                                    <h4 class="text-bold">Amenities</h4>
                                    <ul class="simple">
                                        <li>Air Conditioning</li>
                                        <li>Coffee Maker</li>
                                        <li>Hot Water</li>
                                    </ul>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
        <div class="row mt-3">
            <div class="col-lg-12">
                <div class="card room" id="roomIdDiv2">
                    <div class="card-body">

                        <div class="expand">
                            <div class="row">
                                <div class="col-lg-3">
                                    <img class="img-fluid w-100" src="{{ asset('uploads') }}/hotel/hotel1.png">
                                </div>
                                <div class="col-lg-6">
                                    <h3>Type of Room</h3>
                                    <p class="text-secondary">Max guests # person</p>
                                    <ul class="simple text-secondary">
                                        <li>Special features</li>
                                        <li>Special features</li>
                                        <li>Special features</li>
                                    </ul>
                                </div>
                                <div class="col-lg-3 text-right">
                                    <h4>Rp 1.400.000 <small> / night</small></h4>
                                    <p class="text-primary">Inclusive of taxes</p>
                                    <p>Installment is available for credit cardholders</p>
                                    <a href="#" class="btn btn-tjiburial text-light">Book Now</a>
                                </div>
                            </div>
                        </div>

                        <div class="detail">
                            <div class="row">
                                <div class="col-lg-6">
                                    {{--<h1>Hello</h1>--}}
                                    <img class="img-fluid w-100" src="{{ asset('uploads') }}/hotel/hotel1.png">
                                </div>
                                <div class="col-lg-6">
                                    <h4 class="text-bold">Room Overview</h4>
                                    <ul class="simple">
                                        <li>Bed type : 2 Regular beds</li>
                                    </ul>
                                    <h4 class="text-bold">Basic Facilities</h4>
                                    <ul class="simple">
                                        <li>Breakfast included</li>
                                    </ul>
                                    <h4 class="text-bold">Amenities</h4>
                                    <ul class="simple">
                                        <li>Air Conditioning</li>
                                        <li>Coffee Maker</li>
                                        <li>Hot Water</li>
                                    </ul>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

    @include('frontend.templates.footer')

@endsection