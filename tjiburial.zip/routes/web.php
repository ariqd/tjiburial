<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Auth::routes();

Route::get('/', 'Frontend\HomeController@index');
Route::get('/features', 'Frontend\FeaturesController@index');
//Route::get('/blog', 'Frontend\BlogController@index');
Route::get('/book', 'Frontend\BookController@index');
Route::get('/about', 'Frontend\AboutController@index');
Route::get('/faq', 'Frontend\FaqController@index');
Route::get('/contact', 'Frontend\ContactController@index');

Route::resource('promotion', 'Frontend\PromotionsController');
Route::resource('blog', 'Frontend\BlogController')->only([
    'index', 'show'
]);

Route::group(['middleware' => ['auth', 'is_admin']], function() {
    Route::group(['prefix' => 'admin'], function() {
        Route::get('/', 'Backend\AdminController@index');
        Route::resource('bookings', 'Backend\BookingController');
        Route::resource('rooms', 'Backend\RoomsController');
        Route::resource('blog', 'Backend\BlogController');
    });
});